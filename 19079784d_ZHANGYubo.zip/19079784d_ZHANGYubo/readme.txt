﻿**************************************************************************
This is the readme file of the assignment submission documents set folder. 
**************************************************************************

1. General Info
	Project: 7-23-​Café​ Food Service Order System
	Name: ZHANG Yubo
	ID: 19079784d
2. Files inncluded in this folder are:
	2.0 The file list
		* ​assign2_main.cpp
		* ​design_notes.docx
		* sample_program_output_doc.docx
		* readme.txt
	
	2.1 The source code: 
		assign2_main.cpp
	
	2.2 The System Design document:
		 design_noted.docx

	2.3 The Sample Program Output:
		 sample_program_output_doc.docx
		
	2.4 readme.txt:
		 this file.
		
t to my github:  https://github.com/ZHANGYuboPolyU/cpp/tree/master/19079784d_ZHANGYubo